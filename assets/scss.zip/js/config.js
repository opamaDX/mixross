// global variables for using throughout the template

CustomEase.create("CubicBezier", ".77,0,.18,1");
var zanimationDefaults = {from:{opacity: 0, y: 65}, to:{opacity: 1, y: 0}, ease:"CubicBezier", duration:1.2, delay: 0};
